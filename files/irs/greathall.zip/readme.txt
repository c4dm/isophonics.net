This collection of impulse responses was measured in the Great Hall at the Mile End campus of Queen Mary, University of London in 2008.  The measurements were created using the sine sweep technique [1] with a Genelec 8250A loudspeaker and two microphones, an omnidirectional DPA 4006 and a B-format Soundfield SPS422B.

169 receiver positions were measured with both microphones with the loudspeaker kept static.  The filenames indicate the microphone/channel and position.

For example, Yx04y10.wav is the Y channel, up-down bidirectional, from the Soundfield microphone at the 5th column from the right of the 11th row from the front when facing the loudspeaker.  x00y09.wav is the DPA microphone at the 1st column from the left of the 10th row from the front when facing the loudspeaker.

These IRs are released under the Creative Commons Attribution-Noncommercial-Share-Alike license with attribution to the Centre for Digital Music, Queen Mary, University of London.



[1] Farina, Angelo, "Simultaneous measurement of impulse response and distortion with a swept sine technique," in 108th AES Convention, Paris, France, February 2000.