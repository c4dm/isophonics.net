==================================================================================
Metric Modulations Dataset
Elio Quinton, 
Centre for Digital Music, Queen Mary University of London 2015
==================================================================================


1 - Brief Description
——————————————————————
We present a dataset of annotations of tracks containing metric modulations.

A metric modulation is defined by a relatively abrupt change of metrical structure over time.

In order to capture this, for each track the annotations consist of:
	- Beat locations
	- Downbeat locations
	- Metric modulation locations (i.e. timestamps of the metrical structure change)
	- All metrical level pulse rates

It comes that the metrical structure (i.e. beat rate, downbeat rate and all other metrical level pulse rates) are relatively consistent between two metric modulations.


2 - Citation
—————————————

If you make use of this dataset, please cite:
[1]E. Quinton, K. O'Hanlon, S. Dixon and M. Sandler, “Tracking Metrical Structure Changes With Sparse NMF,” in IEEE International Conference on Acoustics, Speech and Signal Processing (ICASSP), 2017.


3 - Data Structure
———————————————————


The annotations dataset is presented in JSON format in order to be easily parsed while being human readable. 

It is made of a list of objects, each object corresponding to a track.

For each track the object contains the following fields:
	- ’Title’: the title of the piece
	- ‘Artist’: the artist
	- ‘Release’: the name of the release on which the track appears (typically an album)
	- ‘ISRC’: the ISRC code of the annotated track.
	- ‘track name’: the name of the audio file used for annotations.
	- ‘beats’: all the beat positions is seconds
	- ‘downbeats’: all the downbeat positions in seconds
	- ‘segBoundaries’: the metric modulation positions sin seconds (i.e. the timestamps of the metrical structure changes) 
	- ‘metLevelPulseRates’: the pulse rates (in BPM) of all metrical levels. This includes beat and downbeat rates, but also rate of all other levels (e.g. tatum).

