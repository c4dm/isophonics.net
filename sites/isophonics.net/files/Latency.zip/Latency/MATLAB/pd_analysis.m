pd_results = zeros(12, 7);

figure(1);

pd_results(1,:) = latency_analysis('teensy2 - midi - pd - 64-0 - callbacks.txt');
pd_results(2,:) = latency_analysis('teensy2 - midi - pd - 64-0.txt');
pd_results(3,:) = latency_analysis('teensy2 - mouse - pd - 64-0 - callbacks.txt');
pd_results(4,:) = latency_analysis('teensy2 - mouse - pd - 64-0.txt');
pd_results(5,:) = latency_analysis('teensy2 - trigger - pd - 64-0.txt');
pd_results(6,:) = latency_analysis('teensy2 - stream_delay5 - pd - 64-0.txt');
pd_results(7,:) = latency_analysis('teensy2 - stream - pd - 64-0.txt');
pd_results(8,:) = latency_analysis('arduino 115200 - trigger - pd - 64-0.txt');
pd_results(9,:) = latency_analysis('arduino 115200 - stream_delay5 - pd - 64-0.txt');
pd_results(10,:) = latency_analysis('arduino 115200 - stream - pd - 64-0.txt');
pd_results(11,:) = latency_analysis('arduino 9600 - stream_delay5 - pd - 64-0.txt');
pd_results(12,:) = latency_analysis('arduino 9600 - stream - pd - 64-0.txt');

figure(2);

bar(pd_results(:,1));
title('Mean latency');

figure(3);

bar(pd_results(:,7));
title('Jitter');

figure(4);

hold off;
errorbar(1:12, pd_results(:,1), pd_results(:,1) - pd_results(:,5), pd_results(:,6) - pd_results(:,1));
hold on;

plot([1 12], [10 10], 'k--');

v = 11;
offset = -0.3;
h = text(1 + offset, v, 'Teensy 2.0, USB-MIDI, callbacks enabled');
set(h, 'rotation', 90);
h = text(2 + offset, v, 'Teensy 2.0, USB-MIDI');
set(h, 'rotation', 90);
h = text(3 + offset, v, 'Teensy 2.0, USB mouse, callbacks enabled');
set(h, 'rotation', 90);
h = text(4 + offset, v, 'Teensy 2.0, USB mouse');
set(h, 'rotation', 90);
h = text(5 + offset, v, 'Teensy 2.0, USB-serial, send only on event');
set(h, 'rotation', 90);
h = text(6 + offset, v, 'Teensy 2.0, USB-serial, stream with 5ms delay');
set(h, 'rotation', 90);
h = text(7 + offset, v, 'Teensy 2.0, USB-serial, stream with no delay');
set(h, 'rotation', 90);
h = text(8 + offset, v, 'Uno @ 115200bps, send only on event');
set(h, 'rotation', 90);
h = text(9 + offset, v, 'Uno @ 115200bps, stream with 5ms delay');
set(h, 'rotation', 90);
h = text(10 + offset, v, 'Uno @ 115200bps, stream with no delay');
set(h, 'rotation', 90);
h = text(11 + offset, v, 'Uno @ 9600bps, stream with 5ms delay');
set(h, 'rotation', 90);
h = text(12 + offset, v, 'Uno @ 9600bps, stream with no delay');
set(h, 'rotation', 90);

title('Pd-extended 0.43.4, block size = 64, delay = 0, with various triggers');
ylabel('Latency (ms) -- bars indicate 95% range');
xlim([0 13]);