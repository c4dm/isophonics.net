max_qmetro_results = zeros(10, 7);

figure(1);

max_qmetro_results(1,:) = latency_analysis('arduino 115200 - trigger - max - 32-32 - qmetro 2.txt');
max_qmetro_results(2,:) = latency_analysis('arduino 115200 - trigger - max - 32-32 - qmetro 5.txt');
max_qmetro_results(3,:) = latency_analysis('arduino 115200 - trigger - max - 32-32 - qmetro 10.txt');
max_qmetro_results(4,:) = latency_analysis('arduino 115200 - trigger - max - 32-32 - qmetro 20.txt');
max_qmetro_results(5,:) = latency_analysis('arduino 115200 - trigger - max - 128-32 - qmetro 5.txt');
max_qmetro_results(6,:) = latency_analysis('arduino 115200 - trigger - max - 128-32 - qmetro 10.txt');
max_qmetro_results(7,:) = latency_analysis('arduino 115200 - trigger - max - 128-32 - qmetro 20.txt');
max_qmetro_results(8,:) = latency_analysis('arduino 115200 - trigger - max - 512-32 - qmetro 5.txt');
max_qmetro_results(9,:) = latency_analysis('arduino 115200 - trigger - max - 512-32 - qmetro 10.txt');
max_qmetro_results(10,:) = latency_analysis('arduino 115200 - trigger - max - 512-32 - qmetro 20.txt');


figure(2);

bar(max_qmetro_results(:,1));
title('Mean latency');

figure(3);

bar(max_qmetro_results(:,7));
title('Jitter');

figure(4);

hold off;
errorbar(1:4, max_qmetro_results(1:4,1), max_qmetro_results(1:4,1) - max_qmetro_results(1:4,5), max_qmetro_results(1:4,6) - max_qmetro_results(1:4,1));
hold on;
errorbar(5:7, max_qmetro_results(5:7,1), max_qmetro_results(5:7,1) - max_qmetro_results(5:7,5), max_qmetro_results(5:7,6) - max_qmetro_results(5:7,1));
errorbar(8:10, max_qmetro_results(8:10,1), max_qmetro_results(8:10,1) - max_qmetro_results(8:10,5), max_qmetro_results(8:10,6) - max_qmetro_results(8:10,1));

plot([1 10], [10 10], 'k--');

v = 11;
offset = -0.2;
h = text(1 + offset, v, 'Block Size 32, [qmetro 2]');
set(h, 'rotation', 90);
h = text(2 + offset, v, 'Block Size 32, [qmetro 5]');
set(h, 'rotation', 90);
h = text(3 + offset, v, 'Block Size 32, [qmetro 10]');
set(h, 'rotation', 90);
h = text(4 + offset, v, 'Block Size 32, [qmetro 20]');
set(h, 'rotation', 90);
h = text(5 + offset, v, 'Block Size 128, [qmetro 5]');
set(h, 'rotation', 90);
h = text(6 + offset, v, 'Block Size 128, [qmetro 10]');
set(h, 'rotation', 90);
h = text(7 + offset, v, 'Block Size 128, [qmetro 20]');
set(h, 'rotation', 90);
h = text(8 + offset, v, 'Block Size 512, [qmetro 5]');
set(h, 'rotation', 90);
h = text(9 + offset, v, 'Block Size 512, [qmetro 10]');
set(h, 'rotation', 90);
h = text(10 + offset, v, 'Block Size 512, [qmetro 20]');
set(h, 'rotation', 90);

title('Arduino Uno @ 115200bps connected to Max/MSP 6.1.9');
ylabel('Latency (ms) -- bars indicate 95% range');
ylim([0 45]);
xlim([0 11]);