figure(4)

hold off;
errorbar(1:3, bela_audio_results(1:3,1), bela_audio_results(1:3,1) - bela_audio_results(1:3,5), bela_audio_results(1:3,6) - bela_audio_results(1:3,1), 'b');
hold on;
errorbar(1:3, bela_analog_results(1:3,1), bela_analog_results(1:3,1) - bela_analog_results(1:3,5), bela_analog_results(1:3,6) - bela_analog_results(1:3,1), 'r');

errorbar(4:6, bela_audio_results(4:6,1), bela_audio_results(4:6,1) - bela_audio_results(4:6,5), bela_audio_results(4:6,6) - bela_audio_results(4:6,1), 'b');
errorbar(7:12, bela_audio_results(7:12,1), bela_audio_results(7:12,1) - bela_audio_results(7:12,5), bela_audio_results(7:12,6) - bela_audio_results(7:12,1), 'b');

errorbar(4:6, bela_analog_results(4:6,1), bela_analog_results(4:6,1) - bela_analog_results(4:6,5), bela_analog_results(4:6,6) - bela_analog_results(4:6,1), 'r');
errorbar(7:12, bela_analog_results(7:12,1), bela_analog_results(7:12,1) - bela_analog_results(7:12,5), bela_analog_results(7:12,6) - bela_analog_results(7:12,1), 'r');


plot([1 12], [10 10], 'k--');

v = 10.5;
offset = -0.2;
h = text(1 + offset, v, 'Block = 4, 88.2kHz I/O');
set(h, 'rotation', 90);
h = text(2 + offset, v, 'Block = 8, 88.2kHz I/O');
set(h, 'rotation', 90);
h = text(3 + offset, v, 'Block = 16, 88.2kHz I/O');
set(h, 'rotation', 90);
h = text(4 + offset, v, 'Block = 2, 44.1kHz I/O');
set(h, 'rotation', 90);
h = text(5 + offset, v, 'Block = 4, 44.1kHz I/O');
set(h, 'rotation', 90);
h = text(6 + offset, v, 'Block = 8, 44.1kHz I/O');
set(h, 'rotation', 90);
h = text(7 + offset, v, 'Block = 1, 22.05kHz I/O');
set(h, 'rotation', 90);
h = text(8 + offset, v, 'Block = 2, 22.05kHz I/O');
set(h, 'rotation', 90);
h = text(9 + offset, v, 'Block = 4, 22.05kHz I/O');
set(h, 'rotation', 90);
h = text(10 + offset, v, 'Block = 8, 22.05kHz I/O');
set(h, 'rotation', 90);
h = text(11 + offset, v, 'Block = 16, 22.05kHz I/O');
set(h, 'rotation', 90);
h = text(12 + offset, v, 'Block = 32, 22.05kHz I/O');
set(h, 'rotation', 90);

title('Bela: Analog Input and Audio Output');
ylabel('Latency (ms) -- bars indicate 95% range');
ylim([0 20]);
xlim([0 13]);