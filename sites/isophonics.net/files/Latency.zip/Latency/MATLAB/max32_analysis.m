max_block32_results = zeros(15, 7);

figure(1);

max_block32_results(1,:) = latency_analysis('teensy2 - midi - max - 32-32 - overdrive-interrupt.txt');
max_block32_results(2,:) = latency_analysis('teensy2 - midi - max - 32-32.txt');
max_block32_results(3,:) = latency_analysis('teensy2 - mouse - max - 32-32.txt');
max_block32_results(4,:) = latency_analysis('teensy2 - trigger - max - 32-32 - qmetro 2.txt');
max_block32_results(5,:) = latency_analysis('teensy2 - trigger - max - 32-32 - qmetro 5.txt');
max_block32_results(6,:) = latency_analysis('teensy2 - stream_delay5 - max - 32-32 - qmetro 10.txt');
max_block32_results(7,:) = latency_analysis('arduino 115200 - trigger - max - 32-32 - qmetro 2.txt');
max_block32_results(8,:) = latency_analysis('arduino 115200 - trigger - max - 32-32 - qmetro 5.txt');
max_block32_results(9,:) = latency_analysis('arduino 115200 - trigger - max - 32-32 - qmetro 10.txt');
max_block32_results(10,:) = latency_analysis('arduino 115200 - trigger - max - 32-32 - qmetro 20.txt');
max_block32_results(11,:) = latency_analysis('arduino 115200 - stream_delay5 - max - 32-32 - qmetro 5.txt');
max_block32_results(12,:) = latency_analysis('arduino 115200 - stream - max - 32-32 - qmetro 5.txt');
max_block32_results(13,:) = latency_analysis('arduino 9600 - trigger - max - 32-32 - qmetro 5.txt');
max_block32_results(14,:) = latency_analysis('arduino 9600 - stream_delay5 - max - 32-32 - qmetro 10.txt');
max_block32_results(15,:) = latency_analysis('arduino 9600 - stream - max - 32-32 - qmetro 10.txt');

figure(2);

bar(max_block32_results(:,1));
title('Mean latency');

figure(3);

bar(max_block32_results(:,7));
title('Jitter');

figure(4);

hold off;
errorbar(1:15, max_block32_results(:,1), max_block32_results(:,1) - max_block32_results(:,5), max_block32_results(:,6) - max_block32_results(:,1));
hold on;
plot([1 15], [10 10], 'k--');

v = 11;
offset = -0.3;
h = text(1 + offset, v, 'Teensy 2.0, USB-MIDI, Overdrive Interrupts in Scheduler');
set(h, 'rotation', 90);
h = text(2 + offset, v, 'Teensy 2.0, USB-MIDI');
set(h, 'rotation', 90);
h = text(3 + offset, v, 'Teensy 2.0, USB mouse click emulation');
set(h, 'rotation', 90);
h = text(4 + offset, v, 'Teensy 2.0, USB-serial, [qmetro 2], send only on event');
set(h, 'rotation', 90);
h = text(5 + offset, v, 'Teensy 2.0, USB-serial, [qmetro 5], send only on event');
set(h, 'rotation', 90);
h = text(6 + offset, v, 'Teensy 2.0, USB-serial, [qmetro 5], stream with 5ms delay');
set(h, 'rotation', 90);
h = text(7 + offset, v, 'Uno @ 115200bps, [qmetro 2], send only on event');
set(h, 'rotation', 90);
h = text(8 + offset, v, 'Uno @ 115200bps, [qmetro 5], send only on event');
set(h, 'rotation', 90);
h = text(9 + offset, v, 'Uno @ 115200bps, [qmetro 10], send only on event');
set(h, 'rotation', 90);
h = text(10 + offset, v, 'Uno @ 115200bps, [qmetro 20], send only on event');
set(h, 'rotation', 90);
h = text(11 + offset, v, 'Uno @ 115200bps, [qmetro 5], stream with 5ms delay');
set(h, 'rotation', 90);
h = text(12 + offset, v, 'Uno @ 115200bps, [qmetro 5], stream with no delay');
set(h, 'rotation', 90);
h = text(13 + offset, v, 'Uno @ 9600bps, [qmetro 5], send only on event');
set(h, 'rotation', 90);
h = text(14 + offset, v, 'Uno @ 9600bps, [qmetro 10], stream with 5ms delay');
set(h, 'rotation', 90);
h = text(15 + offset, v, 'Uno @ 9600bps, [qmetro 10], stream with no delay');
set(h, 'rotation', 90);

title('Max/MSP 6.1.9, hardware/signal block size = 32, with various triggers');
ylabel('Latency (ms) -- bars indicate 95% range');