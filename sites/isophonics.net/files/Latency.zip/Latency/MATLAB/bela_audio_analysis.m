bela_audio_results = zeros(12, 7);

figure(1);

bela_audio_results(1,:) = latency_analysis('bela analog to audio -D 0 -H 0 -C 2 -p 4.txt');
bela_audio_results(2,:) = latency_analysis('bela analog to audio -D 0 -H 0 -C 2 -p 8.txt');
bela_audio_results(3,:) = latency_analysis('bela analog to audio -D 0 -H 0 -C 2 -p 16.txt');
bela_audio_results(4,:) = latency_analysis('bela analog to audio -D 0 -H 0 -C 4 -p 2.txt');
bela_audio_results(5,:) = latency_analysis('bela analog to audio -D 0 -H 0 -C 4 -p 4.txt');
bela_audio_results(6,:) = latency_analysis('bela analog to audio -D 0 -H 0 -C 4 -p 8.txt');
bela_audio_results(7,:) = latency_analysis('bela analog to audio -D 0 -H 0 -C 8 -p 1.txt');
bela_audio_results(8,:) = latency_analysis('bela analog to audio -D 0 -H 0 -C 8 -p 2.txt');
bela_audio_results(9,:) = latency_analysis('bela analog to audio -D 0 -H 0 -C 8 -p 4.txt');
bela_audio_results(10,:) = latency_analysis('bela analog to audio -D 0 -H 0 -C 8 -p 8.txt');
bela_audio_results(11,:) = latency_analysis('bela analog to audio -D 0 -H 0 -C 8 -p 16.txt');
bela_audio_results(12,:) = latency_analysis('bela analog to audio -D 0 -H 0 -C 8 -p 32.txt');

figure(2);

bar(bela_audio_results(:,1));
title('Mean latency');

figure(3);

bar(bela_audio_results(:,7));
title('Jitter');

figure(4);

hold off;
errorbar(1:3, bela_audio_results(1:3,1), bela_audio_results(1:3,1) - bela_audio_results(1:3,5), bela_audio_results(1:3,6) - bela_audio_results(1:3,1));
hold on;
errorbar(4:6, bela_audio_results(4:6,1), bela_audio_results(4:6,1) - bela_audio_results(4:6,5), bela_audio_results(4:6,6) - bela_audio_results(4:6,1));
errorbar(7:12, bela_audio_results(7:12,1), bela_audio_results(7:12,1) - bela_audio_results(7:12,5), bela_audio_results(7:12,6) - bela_audio_results(7:12,1));

plot([1 12], [10 10], 'k--');

v = 11;
offset = -0.2;
h = text(1 + offset, v, 'Block Size 4, 88.2kHz I/O');
set(h, 'rotation', 90);
h = text(2 + offset, v, 'Block Size 8, 88.2kHz I/O');
set(h, 'rotation', 90);
h = text(3 + offset, v, 'Block Size 16, 88.2kHz I/O');
set(h, 'rotation', 90);
h = text(4 + offset, v, 'Block Size 2, 44.1kHz I/O');
set(h, 'rotation', 90);
h = text(5 + offset, v, 'Block Size 4, 44.1kHz I/O');
set(h, 'rotation', 90);
h = text(6 + offset, v, 'Block Size 8, 44.1kHz I/O');
set(h, 'rotation', 90);
h = text(7 + offset, v, 'Block Size 1, 22.05kHz I/O');
set(h, 'rotation', 90);
h = text(8 + offset, v, 'Block Size 2, 22.05kHz I/O');
set(h, 'rotation', 90);
h = text(9 + offset, v, 'Block Size 4, 22.05kHz I/O');
set(h, 'rotation', 90);
h = text(10 + offset, v, 'Block Size 8, 22.05kHz I/O');
set(h, 'rotation', 90);
h = text(11 + offset, v, 'Block Size 16, 22.05kHz I/O');
set(h, 'rotation', 90);
h = text(12 + offset, v, 'Block Size 32, 22.05kHz I/O');
set(h, 'rotation', 90);

title('Bela: Analog Input and Audio Output');
ylabel('Latency (ms) -- bars indicate 95% range');
ylim([0 20]);
xlim([0 13]);