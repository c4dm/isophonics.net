xbee_ble_results = zeros(5, 7);

figure(1);

xbee_ble_results(1,:) = latency_analysis('Xbee 9600 - arduino trigger - max 32-32 qmetro 2.txt');
xbee_ble_results(2,:) = latency_analysis('Xbee 9600 - arduino trigger - max 32-32 qmetro 5.txt');
xbee_ble_results(3,:) = latency_analysis('Xbee 9600 - arduino trigger - max 32-32 qmetro 10.txt');
xbee_ble_results(4,:) = latency_analysis('Xbee 9600 - arduino stream_delay5 - max 32-32 qmetro 2.txt');
xbee_ble_results(5,:) = latency_analysis('blemini 57600 - trigger - max 32-32.txt');

figure(2);

bar(xbee_ble_results(:,1));
title('Mean latency');

figure(3);

bar(xbee_ble_results(:,7));
title('Jitter');

figure(4);

hold off;
errorbar(1:5, xbee_ble_results(1:5,1), xbee_ble_results(1:5,1) - xbee_ble_results(1:5,5), xbee_ble_results(1:5,6) - xbee_ble_results(1:5,1));
hold on;
%errorbar(5, xbee_ble_results(5,1), xbee_ble_results(5,1) - xbee_ble_results(5,5), xbee_ble_results(5,6) - xbee_ble_results(5,1));

plot([1 5], [10 10], 'k--');

v = 11;
offset = -0.2;
h = text(1 + offset, v, 'Xbee, send on trigger, [qmetro 2]');
set(h, 'rotation', 90);
h = text(2 + offset, v, 'Xbee, send on trigger, [qmetro 5]');
set(h, 'rotation', 90);
h = text(3 + offset, v, 'Xbee, send on trigger, [qmetro 10]');
set(h, 'rotation', 90);
h = text(4 + offset, v, 'Xbee, stream w/5ms delay, [qmetro 2]');
set(h, 'rotation', 90);
h = text(5 + offset, v, 'BLEmini, send on trigger, with helper program');
set(h, 'rotation', 90);


title('Xbee 9600bps and BLEmini 57600bps to Max/MSP, block size 32');
ylabel('Latency (ms) -- bars indicate 95% range');
xlim([0 6]);