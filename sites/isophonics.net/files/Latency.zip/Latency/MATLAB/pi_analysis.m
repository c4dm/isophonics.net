pi_results = zeros(6, 7);

figure(1);

pi_results(1,:) = latency_analysis('pi2 - internal - arduino - pd - 64-22ms.txt');
pi_results(2,:) = latency_analysis('pi2 - internal - gpio - pd - 64-22ms.txt');
pi_results(3,:) = latency_analysis('pi2 - internal - gpio - pd -rt - 64-22ms.txt');
pi_results(4,:) = latency_analysis('pi2 - external - arduino - pd - 64-6ms.txt');
pi_results(5,:) = latency_analysis('pi2 - external - gpio - pd - 64-6ms.txt');
pi_results(6,:) = latency_analysis('pi2 - external - gpio - pd -rt 64-10ms.txt');

figure(2);

bar(pi_results(:,1));
title('Mean latency');

figure(3);

bar(pi_results(:,7));
title('Jitter');

figure(4);

hold off;
errorbar(1:6, pi_results(:,1), pi_results(:,1) - pi_results(:,5), pi_results(:,6) - pi_results(:,1));
hold on;

plot([1 6], [10 10], 'k--');

v = 11;
offset = -0.2;
h = text(1 + offset, v, 'Arduino Uno GPIO, internal sound, 22ms delay');
set(h, 'rotation', 90);
h = text(2 + offset, v, 'Pi2 GPIO, internal sound, 22ms delay');
set(h, 'rotation', 90);
h = text(3 + offset, v, 'Pi2 GPIO, internal sound, 22ms delay, -rt flag');
set(h, 'rotation', 90);
h = text(4 + offset, v, 'Arduino Uno GPIO, USB sound, 22ms delay');
set(h, 'rotation', 90);
h = text(5 + offset, v, 'Pi2 GPIO, USB sound, 22ms delay');
set(h, 'rotation', 90);
h = text(6 + offset, v, 'Pi2 GPIO, USB sound, 22ms delay, -rt flag');
set(h, 'rotation', 90);


title('Raspberry Pi 2, Pd-extended 0.43.4, block size = 64, with various triggers and output');
ylabel('Latency (ms) -- bars indicate 95% range');
xlim([0 7]);