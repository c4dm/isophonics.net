xosc_results = zeros(9, 7);

figure(1);

xosc_results(1,:) = latency_analysis('xosc - router - digital in OSC - max 32-32.txt');
xosc_results(2,:) = latency_analysis('xosc - router - analog in 50Hz OSC - max 32-32.txt');
xosc_results(3,:) = latency_analysis('xosc - router - analog in 100Hz OSC - max 32-32.txt');
xosc_results(4,:) = latency_analysis('xosc - router - analog in 200Hz OSC - max 32-32.txt');
xosc_results(5,:) = latency_analysis('xosc - router - analog in 400Hz OSC - max 32-32.txt');
xosc_results(6,:) = latency_analysis('xosc - imacWifi unicast- digital in OSC - max 32-32.txt');
xosc_results(7,:) = latency_analysis('xosc - imacWifi unicast- analog in 50Hz OSC - max 32-32.txt');
xosc_results(8,:) = latency_analysis('xosc - imacWifi unicast- analog in 100Hz OSC - max 32-32.txt');
xosc_results(9,:) = latency_analysis('xosc - imacWifi unicast- analog in 200Hz OSC - max 32-32.txt');

figure(2);

bar(xosc_results(:,1));
title('Mean latency');

figure(3);

bar(xosc_results(:,7));
title('Jitter');

figure(4);

hold off;
errorbar(1:5, xosc_results(1:5,1), xosc_results(1:5,1) - xosc_results(1:5,5), xosc_results(1:5,6) - xosc_results(1:5,1));
hold on;
errorbar(6:9, xosc_results(6:9,1), xosc_results(6:9,1) - xosc_results(6:9,5), xosc_results(6:9,6) - xosc_results(6:9,1));

plot([1 9], [10 10], 'k--');

v = 11;
offset = -0.2;
h = text(1 + offset, v, 'Router, digital input trigger');
set(h, 'rotation', 90);
h = text(2 + offset, v, 'Router, analog input 50Hz sampling');
set(h, 'rotation', 90);
h = text(3 + offset, v, 'Router, analog input 100Hz sampling');
set(h, 'rotation', 90);
h = text(4 + offset, v, 'Router, analog input 200Hz sampling');
set(h, 'rotation', 90);
h = text(5 + offset, v, 'Router, analog input 400Hz sampling');
set(h, 'rotation', 90);
h = text(6 + offset, v, 'iMac WiFi, digital input trigger');
set(h, 'rotation', 90);
h = text(7 + offset, v, 'iMac WiFi, analog input 50Hz sampling');
set(h, 'rotation', 90);
h = text(8 + offset, v, 'iMac WiFi, analog input 100Hz sampling');
set(h, 'rotation', 90);
h = text(9 + offset, v, 'iMac WiFi, analog input 400Hz sampling');
set(h, 'rotation', 90);

title('x-OSC WiFi board connected to Max/MSP, block size 32');
ylabel('Latency (ms) -- bars indicate 95% range');
ylim([0 100]);
xlim([0 10]);