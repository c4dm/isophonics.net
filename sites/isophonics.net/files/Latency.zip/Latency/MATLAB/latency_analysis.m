function result = latency_analysis(name)

data = csvread(name);

data = data/1000;

histogram(data, 20);
title(name);

data_mean = mean(data)
data_std = std(data)
data_min = min(data)
data_max = max(data)

sorted = sort(data);

min05 = sorted(floor(length(data)*.025))
max05 = sorted(floor(length(data)*.975))

jitter = max05 - min05

result = [data_mean data_std data_min data_max min05 max05 jitter];

end