/*
 * render.cpp
 *
 *  Created on: Oct 24, 2014
 *      Author: parallels
 */


#include <BeagleRT.h>
#include <Utilities.h>
#include <rtdk.h>
#include <cmath>

const int gAnalogInputPin = 0;
const int gAnalogOutputPin = 0;
const bool gUseAnalogOutput = true;

float gRampValue = 0;
float gRampIncrement = 0;
bool gInputWasHigh = false;

// setup() is called once before the audio rendering starts.
// Use it to perform any initialisation and allocation which is dependent
// on the period size or sample rate.
//
// userData holds an opaque pointer to a data structure that was passed
// in from the call to initAudio().
//
// Return true on success; returning false halts the program.

bool setup(BeagleRTContext *context, void *userData)
{
	if(context->analogChannels != 2 &&
	   context->analogChannels != 4 &&
	   context->analogChannels != 8) {
		rt_printf("Error: this example needs analog enabled with 2, 4 or 8 channels\n");
		return false;
	}
	
	// Amount of change to ramp from 1 to 0 in 0.05s:
	gRampIncrement = 20.0 / context->audioSampleRate;
	
	return true;
}

// render() is called regularly at the highest priority by the audio engine.
// Input and output are given from the audio hardware and the other
// ADCs and DACs (if available). If only audio is available, numMatrixFrames
// will be 0.

void render(BeagleRTContext *context, void *userData)
{
	for(int n = 0; n < context->analogFrames; n++) {
		float inputValue = analogReadFrame(context, n, gAnalogInputPin);
		
		if(gRampValue == 0) {
			// Not currently triggered: look for an input above 1V
			if(inputValue >= 0.25 && !gInputWasHigh) {
				gRampValue = 1;
			}
		}	
		else {
			// Currently triggered: ramp down over 50ms
			gRampValue -= gRampIncrement;
			if(gRampValue < 0)
				gRampValue = 0;
		}
		
		gInputWasHigh = (inputValue >= 0.25);
		
		if(gUseAnalogOutput) {
			analogWriteFrame(context, n, gAnalogOutputPin, gRampValue);
		}
		else {
			// Translate the ramp into an audio output
			if(context->analogChannels == 2) {
				// Analog is running at twice the audio rate
				// Audio sample index is half the analog sample index
				context->audioOut[(n/2)*context->audioChannels] = -gRampValue;
				context->audioOut[(n/2)*context->audioChannels + 1] = -gRampValue;
			}
			else if(context->analogChannels == 4) {
				// Analog is running at the audio rate
				// Audio sample index is identical to the analog sample index
				context->audioOut[n*context->audioChannels] = -gRampValue;
				context->audioOut[n*context->audioChannels + 1] = -gRampValue;			
			}
			else if(context->analogChannels == 8) {
				// Analog is running at half the audio rate
				// Audio sample index is twice the analog sample index, and sample
				// needs to be duplicated
				context->audioOut[2*n*context->audioChannels] = -gRampValue;			
				context->audioOut[2*n*context->audioChannels + 1] = -gRampValue;	
				context->audioOut[2*n*context->audioChannels + 2] = -gRampValue;	
				context->audioOut[2*n*context->audioChannels + 3] = -gRampValue;	
			}
		}
	}
}

// cleanup() is called once at the end, after the audio has stopped.
// Release any resources that were allocated in setup().

void cleanup(BeagleRTContext *context, void *userData)
{

}
